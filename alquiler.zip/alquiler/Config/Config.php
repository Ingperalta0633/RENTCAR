<?php
const base_url = "http://localhost:8080/alquiler/";
const host = "localhost";
const user = "root";
const pass = "";
const db = "alquiler";
const charset = "charset=utf8";
?>